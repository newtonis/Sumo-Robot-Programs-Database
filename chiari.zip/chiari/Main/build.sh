/opt/microchip/mplabx/v3.26/mplab_ide/bin/mdb.sh prog.cmd
read -r -p "Press any key to continue..." key